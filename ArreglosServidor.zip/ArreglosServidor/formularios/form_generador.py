class GeneradorForm:
    def __init__(self, data):
        self.modelo = data.get('modelo')
        self.costo = data.get('costo')
        self.consumo_comustible = data.get('consumoComustible')
        self.energia_generada = data.get('energiaGenerada')
        self.uso = data.get('uso')
        self.errores = []

    def es_valido(self):
        def es_decimal(valor):
            try:
                float(valor)
                return True
            except ValueError:
                return False
        if not self.modelo:
            self.errores.append("El modelo es obligatorio.")
        if not self.costo or not es_decimal(self.costo):
            self.errores.append("El costo debe ser un numero valido.")
        else:
            try:
                self.costo = float(self.costo)
            except ValueError:
                self.errores.append("El costo debe ser un numero valido.")
        if not self.consumo_comustible or not es_decimal(self.consumo_comustible):
            self.errores.append("El consumo de combustible debe ser un numero valido.")
        else:
            try:
                self.consumo_comustible = float(self.consumo_comustible)
            except ValueError:
                self.errores.append("El consumo de combustible debe ser un numero valido.")
        if not self.energia_generada or not es_decimal(self.energia_generada):
            self.errores.append("La energia generada debe ser un numero valido.")
        else:
            try:
                self.energia_generada = float(self.energia_generada)
            except ValueError:
                self.errores.append("La energia generada debe ser un numero valido.")
        if self.uso not in ["DOMESTICO", "COMERCIAL"]:
            self.errores.append("El uso debe ser 'DOMESTICO' o 'COMERCIAL'.")
        return len(self.errores) == 0
