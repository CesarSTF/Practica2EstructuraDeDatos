class FamiliaForm:
    def __init__(self, form_data, generadores):
        self.nombre_familia = form_data.get("nombreFamilia", "").strip()
        self.nro_integrantes = form_data.get("nroIntegrantes", "").strip()
        self.id_generador = form_data.get("idGenerador", "").strip()
        self.errores = []
        self.generadores = generadores

    def es_valido(self):
        if not self.nombre_familia:
            self.errores.append("El nombre de la familia es obligatorio.")        
        try:
            self.nro_integrantes = int(self.nro_integrantes)
            if self.nro_integrantes < 1:
                self.errores.append("El numero de integrantes debe ser un numero positivo.")
        except ValueError:
            self.errores.append("El numero de integrantes debe ser un numero valido.")
        
        if self.id_generador:
            try:
                self.id_generador = int(self.id_generador)
            except ValueError:
                self.errores.append("El ID del Generador debe ser un numero valido.")
        
        return len(self.errores) == 0
