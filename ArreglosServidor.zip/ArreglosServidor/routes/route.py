from flask import Blueprint, render_template, jsonify, request, redirect, url_for
import requests
from formularios.form_generador import GeneradorForm
from formularios.form_familia import FamiliaForm

router = Blueprint("router", __name__)
##############################################################################################################
BACKEND_URL_GENERADOR = "http://localhost:8090/api/generador"
BACKEND_URL_FAMILIA = "http://localhost:8090/api/familia"
##############################################################################################################
@router.route("/")
def home():
    try:
        response = requests.get(f"{BACKEND_URL_GENERADOR}/all")
        generadores = response.json().get("data", []) if response.status_code == 200 else []
        response_familias = requests.get(f"{BACKEND_URL_FAMILIA}/all")
        familias = response_familias.json().get("data", []) if response_familias.status_code == 200 else []
    except Exception as e:
        print("Error al conectar con la API de Java:", e)
        generadores = []
        familias = []
    return render_template("home.html", content_template="fragmento/tablaGeneradores.html", generadores=generadores, familias=familias)

@router.route("/nuevo_generador", methods=["GET", "POST"])
def new_generador():
    if request.method == "POST":
        form = GeneradorForm(request.form)
        if form.es_valido():
            data = {
                "modelo": form.modelo,
                "costo": float(form.costo),
                "consumoComustible": float(form.consumo_comustible),
                "energiaGenerada": float(form.energia_generada),
                "uso": form.uso
            }
            response = requests.post(f"{BACKEND_URL_GENERADOR}/create", json=data)
            return redirect(url_for("router.home")) if response.status_code == 200 else render_template("new_generador.html", error="Error al crear el generador")
        else:
            return render_template("new_generador.html", error=form.errores)
    return render_template("new_generador.html")

@router.route("/editar_generador/<int:id>", methods=["GET", "POST"])
def edit_generador(id):
    try:
        response = requests.get(f"{BACKEND_URL_GENERADOR}/get/{id}")
        generador = response.json().get("data")
    except Exception as e:
        print("Error al obtener el generador:", e)
        generador = None
    if request.method == "POST":
        form = GeneradorForm(request.form)
        if form.es_valido():
            data = {
                "modelo": form.modelo,
                "costo": float(form.costo),
                "consumoComustible": float(form.consumo_comustible),
                "energiaGenerada": float(form.energia_generada),
                "uso": form.uso
            }
            response = requests.put(f"{BACKEND_URL_GENERADOR}/update/{id}", json=data)
            return redirect(url_for("router.home")) if response.status_code == 200 else render_template("edit_generador.html", error="Error al modificar el generador", generador=generador)
    return render_template("edit_generador.html", generador=generador)

@router.route("/eliminar_generador/<int:id>", methods=["POST"])
def delete_generador(id):
    response = requests.delete(f"{BACKEND_URL_GENERADOR}/delete/{id}")
    return redirect(url_for("router.home")) if response.status_code == 200 else render_template("home.html", error="Error al eliminar el generador")

##############################################################################################################

@router.route("/familias")
def familias():
    try:
        response = requests.get(f"{BACKEND_URL_FAMILIA}/all")
        familias = response.json().get("data", []) if response.status_code == 200 else []
    except Exception as e:
        print("Error al conectar con la API de Java:", e)
        familias = []
    return render_template("home.html", content_template="fragmento/tablaFamilias.html", familias=familias)

@router.route("/nueva_familia", methods=["GET", "POST"])
def new_familia():
    try:
        response = requests.get(BACKEND_URL_GENERADOR)
        generadores = response.json().get("data", []) if response.status_code == 200 else []
    except Exception as e:
        print("Error al conectar con la API de Java:", e)
        generadores = []
    if request.method == "POST":
        form = FamiliaForm(request.form)
        if form.es_valido():
            data = {
                "nombreFamilia": form.nombre_familia,
                "nroIntegrantes": form.nro_integrantes,
                "generadorId": int(request.form.get("generadorId", 0)) 
            }
            response = requests.post(f"{BACKEND_URL_FAMILIA}/create", json=data)
            return redirect(url_for("router.home")) if response.status_code == 200 else render_template("new_familia.html", error="Error al crear la familia", generadores=generadores)
        else:
            return render_template("new_familia.html", error=form.errores, generadores=generadores)
    return render_template("new_familia.html", generadores=generadores)

@router.route("/editar_familia/<int:id>", methods=["GET", "POST"])
def edit_familia(id):
    try:
        response = requests.get(f"{BACKEND_URL_FAMILIA}/get/{id}")
        familia = response.json().get("data")
        generadores_response = requests.get(BACKEND_URL_GENERADOR)
        generadores = generadores_response.json().get("data", []) if generadores_response.status_code == 200 else []
    except Exception as e:
        print("Error al obtener la familia o los generadores:", e)
        familia = None
        generadores = []
    if request.method == "POST":
        form = FamiliaForm(request.form)
        if form.es_valido():
            data = {
                "nombreFamilia": form.nombre_familia,
                "nroIntegrantes": form.nro_integrantes,
                "generadorId": int(form.id_generador)
                  
            }
            print(data)
            response = requests.put(f"{BACKEND_URL_FAMILIA}/update/{id}", json=data)
            return redirect(url_for("router.familias")) if response.status_code == 200 else render_template("edit_familia.html", error="Error al modificar la familia", familia=familia, generadores=generadores)
    return render_template("edit_familia.html", familia=familia, generadores=generadores)

@router.route("/eliminar_familia/<int:id>", methods=["POST"])
def delete_familia(id):
    response = requests.delete(f"{BACKEND_URL_FAMILIA}/delete/{id}")
    return redirect(url_for("router.familias")) if response.status_code == 200 else render_template("home.html", error="Error al eliminar la familia")
